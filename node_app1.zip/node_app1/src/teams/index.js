const _ = require('lodash');

const teams = [];

const createTeam = (team) => {

  // validations
  if(!validateTeamRequest(team)) {
    return "Invalid Request params";
  }

  let teamIndex = teams.findIndex(entry => { return entry.name === team.name });
  if(teamIndex != -1) {
    teams.splice(teamIndex, 1);
    teams.push(team);
    return "team updated";
  }
  teams.push(team);
  return "team created";
}


const validateTeamRequest = (team) => {
  if(_.isEmpty(team.name) || _.isNull(team.developers)){
    return false;
  }
  return true;
};

const getTeams = () => {
  return teams;
}

module.exports = {
  createTeam,
  getTeams
};