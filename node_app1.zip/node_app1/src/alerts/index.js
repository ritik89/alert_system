const _ = require('lodash');
const axios = require('axios');
const { url } = require('inspector');

const thirdPartyAlertApi = "https://run.mocky.io/v3/fd99c100-f88a-4d70-aaf7-393dbbd5d99f";

const triggerAlert = async (alert) => {

  //validations 
  if(!validatTriggerAlertRequest(alert)) {
    return "Invalid Request params";
  }

  const response = await axios.post(thirdPartyAlertApi, {
      alert
    }
  );
  if(response.status_code != 200) {
    return "Alert not triggered";
  }
  return response.data;
};

const validatTriggerAlertRequest = (alert) => {
  if(_.isEmpty(alert.phone_number) || _.isEmpty(alert.message)){
    return false;
  }
  return true;
};

module.exports = {
  triggerAlert
};