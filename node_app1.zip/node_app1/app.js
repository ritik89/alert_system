'use strict';

const express = require('express');
const { triggerAlert } = require('./src/alerts');
const { createTeam, getTeams } = require('./src/teams');
const app = express();
app.use(express.json());

app.get("/", (req, res) => {
  res.send("Hello World!");
});

// teams
app.post("/teams/addTeam", (req, res) => {
  const response = createTeam(req.body.team);
  res.send(response);
}); 

app.post("/teams/getTeams", (req, res) => {
  res.send(getTeams());
});


// alerts
app.post("/alerts/triggerAlert", async (req, res) => {
  const response = await triggerAlert(req.body.alert);
  res.send(response);
}); 

app.listen(3001, () => {
  console.log("Application started on localhost:3001");
});